package com.netease.cloud.nos.android.receiver;

import com.netease.cloud.nos.android.service.RefreshService;
import com.netease.cloud.nos.android.utils.LogUtil;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class RefreshReceiver extends BroadcastReceiver {

	private static final String LOGTAG = LogUtil
			.makeLogTag(RefreshReceiver.class);

	@Override
	public void onReceive(Context context, Intent intent) {
		LogUtil.d(LOGTAG, "refresh receiver is running");
		context.startService(new Intent(context, RefreshService.class));
	}

}