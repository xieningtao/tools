package com.netease.cloud.nos.android.receiver;

import com.netease.cloud.nos.android.service.MonitorService;
import com.netease.cloud.nos.android.utils.LogUtil;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MonitorReceiver extends BroadcastReceiver {

	private static final String LOGTAG = LogUtil
			.makeLogTag(MonitorReceiver.class);

	@Override
	public void onReceive(Context context, Intent intent) {
		LogUtil.d(LOGTAG, "monitor receiver is running");
		context.startService(new Intent(context, MonitorService.class));
	}
}
