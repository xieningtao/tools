package com.netease.cloud.nos.android.receiver;

import com.netease.cloud.nos.android.service.RefreshService;
import com.netease.cloud.nos.android.utils.LogUtil;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class ConnectionChangeReceiver extends BroadcastReceiver {

	private static final String LOGTAG = LogUtil
			.makeLogTag(ConnectionChangeReceiver.class);

	@Override
	public void onReceive(Context context, Intent intent) {
		LogUtil.d(LOGTAG, "connection change receiver is running");
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = cm.getActiveNetworkInfo();
		if (cm != null && networkInfo != null
				&& networkInfo.isAvailable()
				&& networkInfo.isConnected()) {
			context.startService(new Intent(context, RefreshService.class));
		}
	}
}
