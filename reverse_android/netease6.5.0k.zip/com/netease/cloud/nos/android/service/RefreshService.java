package com.netease.cloud.nos.android.service;

import com.netease.cloud.nos.android.constants.Constants;
import com.netease.cloud.nos.android.core.IOManager;
import com.netease.cloud.nos.android.core.WanAccelerator;
import com.netease.cloud.nos.android.utils.LogUtil;
import com.netease.cloud.nos.android.utils.Util;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class RefreshService extends Service {

	private static final String LOGTAG = LogUtil
			.makeLogTag(RefreshService.class);

	@Override
	public IBinder onBind(Intent intent) {
		LogUtil.d(LOGTAG, "Service onBind");
		return null;
	}

	@Override
	public void onCreate() {
		LogUtil.d(LOGTAG, "Service onCreate");
		super.onCreate();
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onStart(Intent intent, int startId) {
		LogUtil.d(LOGTAG, "Service onStart");
		super.onStart(intent, startId);
		String url = Util.getData(this, Constants.LBS_KEY);
		if (url == null) {
			url = WanAccelerator.getConf().getLbsHost();
		}
		final String address = url;
		new Thread(new Runnable() {
			public void run() {
				LogUtil.d(LOGTAG,
						"refresh service is get lbs address with url: "
								+ address);
				int code = IOManager
						.getLBSAddress(RefreshService.this, address);
				LogUtil.d(LOGTAG, "refresh service get result code: " + code);
			}
		}).start();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		LogUtil.d(LOGTAG, "Service onStartCommand");
		return super.onStartCommand(intent, flags, startId);
	}
}
