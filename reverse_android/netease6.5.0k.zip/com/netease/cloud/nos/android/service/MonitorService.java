package com.netease.cloud.nos.android.service;

import com.netease.cloud.nos.android.core.WanAccelerator;
import com.netease.cloud.nos.android.monitor.MonitorHttp;
import com.netease.cloud.nos.android.utils.LogUtil;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class MonitorService extends Service {

	private static final String LOGTAG = LogUtil
			.makeLogTag(MonitorService.class);

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	@Override
	public void onCreate() {
		LogUtil.d(LOGTAG, "Service onCreate");
		super.onCreate();
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onStart(Intent intent, int startId) {
		LogUtil.d(LOGTAG, "Service onStart");
		super.onStart(intent, startId);
		new Thread(new Runnable() {
			@Override
			public void run() {
				MonitorHttp.post(MonitorService.this, WanAccelerator.getConf().getMonitorHost());
			}
		}).start();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		LogUtil.d(LOGTAG, "Service onStartCommand");
		return super.onStartCommand(intent, flags, startId);
	}

}
