package com.netease.cloud.nos.android.monitor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPOutputStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.netease.cloud.nos.android.constants.Code;
import com.netease.cloud.nos.android.utils.LogUtil;
import com.netease.cloud.nos.android.utils.Util;

public class Monitor {

	private static final String LOGTAG = LogUtil.makeLogTag(Monitor.class);

	public static List<StatisticItem> LIST = new ArrayList<StatisticItem>();

	public static synchronized ByteArrayOutputStream getPostData() {
		if (LIST.size() == 0) {
			return null;
		}
		GZIPOutputStream gos = null;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			gos = new GZIPOutputStream(bos);
			JSONArray array = new JSONArray();
			for (StatisticItem item : LIST) {
				array.put(toJSON(item));
			}
			JSONObject jo = new JSONObject();
			jo.put("items", array);
			LogUtil.e(LOGTAG, "monitor result: " + jo.toString());
			gos.write(jo.toString().getBytes("UTF-8"));
			gos.flush();
			gos.finish();
		} catch (IOException e) {
			LogUtil.e(LOGTAG, "get post data io exception", e);
		} catch (JSONException e) {
			LogUtil.e(LOGTAG, "get post data json exception", e);
		} finally {
			if(gos != null) {
				try {
					gos.close();
				} catch (IOException e) {
					LogUtil.e(LOGTAG, "gos close exception", e);
				}
			}
		}
		return bos;
	}

	public static synchronized void clean() {
		LIST.clear();
	}

	private static JSONObject toJSON(StatisticItem item) {
		JSONObject data = new JSONObject();
		try {
			data.put("a", item.getPlatform());
			if (item.getClientIP() != null && !item.getClientIP().equals("")) {
				data.put("b", Util.ipToLong(item.getClientIP()));
			}
			data.put("c", item.getSdkVersion());
			if (item.getLbsIP() != null && !item.getLbsIP().equals("")) {
				data.put("d", Util.ipToLong(Util.getIPString(item.getLbsIP())));
			}
			data.put("e", Util.ipToLong(Util.getIPString(item.getUploaderIP())));
			data.put("f", item.getFileSize());
			data.put("g", item.getNetEnv());
			if (item.getLbsUseTime() != Code.MONITOR_SUCCESS) {
				data.put("h", item.getLbsUseTime());
			}
			data.put("i", item.getUploaderUseTime());
			if (item.getLbsSucc() != Code.MONITOR_SUCCESS) {
				data.put("j", item.getLbsSucc());
			}
			if (item.getUploaderSucc() != Code.MONITOR_SUCCESS) {
				data.put("k", item.getUploaderSucc());
			}
			if (item.getLbsHttpCode() != Code.HTTP_SUCCESS) {
				data.put("l", item.getLbsHttpCode());
			}
			if (item.getUploaderHttpCode() != Code.HTTP_SUCCESS) {
				data.put("m", item.getUploaderHttpCode());
			}
			if (item.getUploadRetryCount() != Code.MONITOR_SUCCESS) {
				data.put("n", item.getUploadRetryCount());
			}
			if (item.getChunkRetryCount() != Code.MONITOR_SUCCESS) {
				data.put("o", item.getChunkRetryCount());
			}
			if (item.getQueryRetryCount() != Code.MONITOR_SUCCESS) {
				data.put("p", item.getQueryRetryCount());
			}
			if (item.getBucketName() != null && !item.getBucketName().equals("")) {
				data.put("q", item.getBucketName());
			}
		} catch (JSONException e) {
			LogUtil.e(LOGTAG, "parse statistic item json exception", e);
		}
		return data;
	}
}
