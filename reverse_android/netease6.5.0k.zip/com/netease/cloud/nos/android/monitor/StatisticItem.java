package com.netease.cloud.nos.android.monitor;

public class StatisticItem {

	private final String platform = "android";
	private String clientIP;
	private final String sdkVersion = "1.0";
	private String lbsIP;
	private String uploaderIP;
	private long fileSize;
	private String netEnv;
	private long lbsUseTime;
	private long uploaderUseTime;
	private int lbsSucc = 0;
	private int uploaderSucc = 0;
	private int lbsHttpCode = 200;
	private int uploaderHttpCode = 200;
	private int chunkRetryCount = 0;
	private int queryRetryCount = 0;
	private int uploadRetryCount = 0;
	private String bucketName;
	
	public String getClientIP() {
		return clientIP;
	}

	public void setClientIP(String clientIP) {
		this.clientIP = clientIP;
	}

	public String getLbsIP() {
		return lbsIP;
	}

	public void setLbsIP(String lbsIP) {
		this.lbsIP = lbsIP;
	}

	public String getUploaderIP() {
		return uploaderIP;
	}

	public void setUploaderIP(String uploaderIP) {
		this.uploaderIP = uploaderIP;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public String getNetEnv() {
		return netEnv;
	}

	public void setNetEnv(String netEnv) {
		this.netEnv = netEnv;
	}

	public long getLbsUseTime() {
		return lbsUseTime;
	}

	public void setLbsUseTime(long lbsUseTime) {
		this.lbsUseTime = lbsUseTime;
	}

	public long getUploaderUseTime() {
		return uploaderUseTime;
	}

	public void setUploaderUseTime(long uploaderUseTime) {
		this.uploaderUseTime = uploaderUseTime;
	}

	public int getLbsSucc() {
		return lbsSucc;
	}

	public void setLbsSucc(int lbsSucc) {
		this.lbsSucc = lbsSucc;
	}

	public int getUploaderSucc() {
		return uploaderSucc;
	}

	public void setUploaderSucc(int uploaderSucc) {
		this.uploaderSucc = uploaderSucc;
	}

	public int getLbsHttpCode() {
		return lbsHttpCode;
	}

	public void setLbsHttpCode(int lbsHttpCode) {
		this.lbsHttpCode = lbsHttpCode;
	}

	public int getUploaderHttpCode() {
		return uploaderHttpCode;
	}

	public void setUploaderHttpCode(int uploaderHttpCode) {
		this.uploaderHttpCode = uploaderHttpCode;
	}

	public int getChunkRetryCount() {
		return chunkRetryCount;
	}

	public void setChunkRetryCount(int chunkRetryCount) {
		this.chunkRetryCount = chunkRetryCount;
	}

	public String getPlatform() {
		return platform;
	}

	public String getSdkVersion() {
		return sdkVersion;
	}

	public int getQueryRetryCount() {
		return queryRetryCount;
	}

	public void setQueryRetryCount(int queryRetryCount) {
		this.queryRetryCount = queryRetryCount;
	}

	public int getUploadRetryCount() {
		return uploadRetryCount;
	}

	public void setUploadRetryCount(int uploadRetryCount) {
		this.uploadRetryCount = uploadRetryCount;
	}

	public String getBucketName() {
		return bucketName;
	}
	
	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}
}
