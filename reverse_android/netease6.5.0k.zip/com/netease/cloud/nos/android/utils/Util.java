package com.netease.cloud.nos.android.utils;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.netease.cloud.nos.android.constants.Code;
import com.netease.cloud.nos.android.constants.Constants;
import com.netease.cloud.nos.android.core.Callback;
import com.netease.cloud.nos.android.core.WanNOSObject;
import com.netease.cloud.nos.android.core.WanAccelerator;
import com.netease.cloud.nos.android.exception.InvalidParameterException;
import com.netease.cloud.nos.android.http.HttpResult;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.util.Base64;

public class Util {

	private static final String LOGTAG = LogUtil.makeLogTag(Util.class);

	public static void setData(Context ctx, String key, String value) {
		SharedPreferences mPerferences = getDefaultPreferences(ctx);
		SharedPreferences.Editor mEditor = mPerferences.edit();
		mEditor.putString(key, value);
		mEditor.commit();
	}

	public static String getData(Context ctx, String key) {
		SharedPreferences mPerferences = getDefaultPreferences(ctx);
		return mPerferences.getString(key, null);
	}

	public static HttpPost newPost(String url) {
		return new HttpPost(url);
	}

	public static HttpGet newGet(String url) {
		return new HttpGet(url);
	}

	public static HttpClient getHttpClient(Context ctx) {
		return Http.getHttpClient(ctx);
	}

	private static SharedPreferences getDefaultPreferences(Context ctx) {
		return PreferenceManager.getDefaultSharedPreferences(ctx);
	}

	public static CountDownLatch acquireLock() {
		CountDownLatch latch = new CountDownLatch(1);
		return latch;
	}

	public static void setLock(CountDownLatch latch) {
		try {
			latch.await();
		} catch (InterruptedException e) {
			LogUtil.e(LOGTAG, "set lock with interrupted exception", e);
		}
	}

	public static void releaseLock(CountDownLatch latch) {
		latch.countDown();
	}

	public static void setLBSData(Context ctx, JSONObject rs) {
		try {
			String lbsString = rs.getString("lbs");
			JSONArray uploadArray = rs.getJSONArray("upload");
			String uploadString = transformString(uploadArray);
			LogUtil.d(LOGTAG, "lbsString: " + lbsString);
			LogUtil.d(LOGTAG, "upload server string: " + uploadString);
			if (lbsString != null) {
				Util.setData(ctx, Constants.LBS_KEY, lbsString);
			}
			if (uploadString != null) {
				String httpsUploadString = replaceWithHttps(uploadString);
				LogUtil.d(LOGTAG, "https servers: " + httpsUploadString);
				Util.setData(ctx, Constants.UPLOAD_SERVER_KEY, uploadString);
				Util.setData(ctx, Constants.HTTPS_UPLOAD_SERVER_KEY,
						httpsUploadString);
			}
		} catch (JSONException e) {
			LogUtil.e(LOGTAG, "get json array exception", e);
		}
	}

	public static String[] getUploadServer(Context ctx, boolean isHttps) {
		String str = null;
		if (!isHttps) {
			str = getData(ctx, Constants.UPLOAD_SERVER_KEY);
		} else {
			str = getData(ctx, Constants.HTTPS_UPLOAD_SERVER_KEY);
		}
		if (str == null) {
			return null;
		} else {
			return str.split(";");
		}
	}

	public static String buildLBSUrl(String url) {
		LogUtil.d(LOGTAG, "query lbs url: " + url);
		return url + "?version=" + Constants.LBS_VERSION;
	}

	public static String buildQueryUrl(String server, String bucketName,
			String fileName, String context)
			throws UnsupportedEncodingException {
		String queryString = null;
		if (context != null) {
			queryString = encode(bucketName) + "/" + encode(fileName)
					+ "?uploadContext&version=" + Constants.UPLOAD_VERSION
					+ "&context=" + context;
		} else {
			queryString = encode(bucketName) + "/" + encode(fileName)
					+ "?uploadContext&version=" + Constants.UPLOAD_VERSION;
		}
		return server + "/" + queryString;
	}

	public static String buildPostDataUrl(String server, String bucketName,
			String fileName, String context, long offset, boolean isLast)
			throws UnsupportedEncodingException {
		String queryString = null;
		if (context != null) {
			queryString = encode(bucketName) + "/" + encode(fileName)
					+ "?version=" + Constants.UPLOAD_VERSION + "&context="
					+ context + "&offset=" + offset + "&complete=" + isLast;
		} else {
			queryString = encode(bucketName) + "/" + encode(fileName)
					+ "?version=" + Constants.UPLOAD_VERSION + "&offset="
					+ offset + "&complete=" + isLast;
		}
		LogUtil.d(LOGTAG, "post data url server: " + server
				+ ", query string: " + queryString);
		return server + "/" + queryString;
	}

	public static HttpRequestBase setHeader(HttpRequestBase request,
			Map<String, String> map) {
		if (map == null) {
			return request;
		}
		Set<String> keys = map.keySet();
		for (String s : keys) {
			request.addHeader(s, map.get(s));
		}
		return request;
	}

	public static File getSDPath(Context context) {
		File sdDir = context.getCacheDir();
		boolean sdCardExist = Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED);
		if (sdCardExist) {
			sdDir = Environment.getExternalStorageDirectory();
		}
		return sdDir;
	}

	public static FileInput fromInputStream(Context context, File file,
			String filename) throws IOException {
		// InputStream is = new FileInputStream(f);
		// final File file = storeToFile(context, is);
		if (file == null) {
			return null;
		}
		FileInput isa = null;
		try {
			isa = new FileInput(file, filename);
		} catch (IOException e) {
		/*	if (file != null) {  // ldm：这里可不能删，这可是用户文件
				file.delete();
			}*/
			throw e;
		}
		return isa;
	}

	public static ExecutorService getExecutorService() {
		return Executors.newSingleThreadExecutor();
	}

	public static String getToken(String bucket, String object, long expires,
			String accessKey, String secretKey, String callbackurl,
			String callbackbody) throws NoSuchAlgorithmException,
			InvalidKeyException, JSONException {
		String token = "";

		JSONObject jsonObject = new JSONObject();
		if (bucket != null) {
			jsonObject.put("Bucket", bucket);
		}
		if (object != null) {
			jsonObject.put("Object", object);
		}
		if (expires != 0) {
			jsonObject.put("Expires", expires);
		}
		if (callbackurl != null) {
			jsonObject.put("CallbackUrl", callbackurl);
		}
		if (callbackbody != null) {
			jsonObject.put("CallbackBody", callbackbody);
		}

		String jsonString = jsonObject.toString();
		String encodedPolicy = new String(Base64.encode(jsonString.getBytes(),
				Base64.NO_WRAP));
		SecretKeySpec signingKey = new SecretKeySpec(secretKey.getBytes(),
				"HmacSHA256");
		Mac mac = Mac.getInstance("HmacSHA256");
		mac.init(signingKey);
		byte[] signedPolicy = mac.doFinal(encodedPolicy.getBytes());

		String encodedSign = new String(Base64.encode(signedPolicy,
				Base64.NO_WRAP));

		token = "UPLOAD " + accessKey + ":" + encodedSign + ":" + encodedPolicy;
		return token;
	}

	public static int transformCode(int code) {
		switch (code) {
		case Constants.CODE_SERVER_ERROR:
			return Code.SERVER_ERROR;
		case Constants.CODE_HTTP_EXCEPTION:
			return Code.HTTP_EXCEPTION;
		case Constants.CODE_NO_RESPONSE:
			return Code.HTTP_NO_RESPONSE;
		case Constants.CODE_INVALID_TOKEN:
			return Code.INVALID_TOKEN;
		case Constants.CODE_RETRY:
			return Code.UNKNOWN_REASON;
		}
		return Code.UNKNOWN_REASON;
	}

	public static void deleteTempFiles(Context context) {
		File outputDir = getSDPath(context);
		File dir = new File(outputDir.getPath() + Constants.TEMP_FILE);
		if (dir.exists()) {
			File[] list = dir.listFiles();
			if (list != null) {
				for (File f : list) {
					f.delete();
				}
			}
		}
	}

	public static String getIPAddress() {
		try {
			for (Enumeration<NetworkInterface> en = NetworkInterface
					.getNetworkInterfaces(); en.hasMoreElements();) {
				NetworkInterface intf = en.nextElement();
				for (Enumeration<InetAddress> enumIpAddr = intf
						.getInetAddresses(); enumIpAddr.hasMoreElements();) {
					InetAddress inetAddress = enumIpAddr.nextElement();
					if (!inetAddress.isLoopbackAddress()
							&& (inetAddress instanceof Inet4Address)) {
						return inetAddress.getHostAddress().toString();
					}
				}
			}
		} catch (SocketException ex) {
			LogUtil.e(LOGTAG, "get ip address socket exception");
		}
		return "";
	}

	public static boolean isFastMobileNetwork(Context context) {
		TelephonyManager telephonyManager = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		switch (telephonyManager.getNetworkType()) {
		case TelephonyManager.NETWORK_TYPE_1xRTT:
			return false; // ~ 50-100 kbps
		case TelephonyManager.NETWORK_TYPE_CDMA:
			return false; // ~ 14-64 kbps
		case TelephonyManager.NETWORK_TYPE_EDGE:
			return false; // ~ 50-100 kbps
		case TelephonyManager.NETWORK_TYPE_EVDO_0:
			return true; // ~ 400-1000 kbps
		case TelephonyManager.NETWORK_TYPE_EVDO_A:
			return true; // ~ 600-1400 kbps
		case TelephonyManager.NETWORK_TYPE_GPRS:
			return false; // ~ 100 kbps
		case TelephonyManager.NETWORK_TYPE_HSDPA:
			return true; // ~ 2-14 Mbps
		case TelephonyManager.NETWORK_TYPE_HSPA:
			return true; // ~ 700-1700 kbps
		case TelephonyManager.NETWORK_TYPE_HSUPA:
			return true; // ~ 1-23 Mbps
		case TelephonyManager.NETWORK_TYPE_UMTS:
			return true; // ~ 400-7000 kbps
		case TelephonyManager.NETWORK_TYPE_EHRPD:
			return true; // ~ 1-2 Mbps
		case TelephonyManager.NETWORK_TYPE_EVDO_B:
			return true; // ~ 5 Mbps
		case TelephonyManager.NETWORK_TYPE_HSPAP:
			return true; // ~ 10-20 Mbps
		case TelephonyManager.NETWORK_TYPE_IDEN:
			return false; // ~25 kbps
		case TelephonyManager.NETWORK_TYPE_LTE:
			return true; // ~ 10+ Mbps
		case TelephonyManager.NETWORK_TYPE_UNKNOWN:
			return false;
		default:
			return false;
		}
	}

	public static String getNetWorkType(Context context) {
		ConnectivityManager manager = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = manager.getActiveNetworkInfo();
		if (networkInfo != null && networkInfo.isConnected()) {
			String type = networkInfo.getTypeName();
			if (type.equalsIgnoreCase("WIFI")) {
				return "wifi";
			} else if (type.equalsIgnoreCase("MOBILE")) {
				// String proxyHost = android.net.Proxy.getDefaultHost();
				if (isFastMobileNetwork(context)) {
					return "3g/4g";
				} else {
					return "2g";
				}
			}
		}
		return "";
	}

	public static String getMonitorUrl(String url) {
		return url + "/stat/sdk?version=1.0";
	}

	public static long ipToLong(String strIp) {
		if (strIp == null || strIp.equals("")) {
			return 0L;
		}
		long[] ip = new long[4];
		int position1 = strIp.indexOf(".");
		int position2 = strIp.indexOf(".", position1 + 1);
		int position3 = strIp.indexOf(".", position2 + 1);
		ip[0] = Long.parseLong(strIp.substring(0, position1));
		ip[1] = Long.parseLong(strIp.substring(position1 + 1, position2));
		ip[2] = Long.parseLong(strIp.substring(position2 + 1, position3));
		ip[3] = Long.parseLong(strIp.substring(position3 + 1));
		return (ip[0] << 24) + (ip[1] << 16) + (ip[2] << 8) + ip[3];
	}

	public static String getIPString(String srcIp) {
		if (srcIp == null || srcIp.equals("")) {
			return "";
		}
		if (srcIp.startsWith("https")) {
			srcIp = srcIp.replaceAll("https://", "");
		}
		if (srcIp.startsWith("http")) {
			srcIp = srcIp.replaceAll("http://", "");
		}
		String regexString = ".*(\\d{3}(\\.\\d{1,3}){3}).*";
		String IPString = srcIp.replaceAll(regexString, "$1");
		return IPString;
	}

	public static void addHeaders(HttpPost post, WanNOSObject data) {
		if (data.getContentType() != null && !data.getContentType().equals("")) {
			post.addHeader("Content-Type", data.getContentType());
		}
		if (data.getContentMD5() != null && !data.getContentMD5().equals("")) {
			post.addHeader("Content-MD5", data.getContentMD5());
		}
		if (data.getUserMetadata() != null && data.getUserMetadata().size() > 0) {
			Map<String, String> userMap = data.getUserMetadata();
			for (String key : userMap.keySet()) {
				post.addHeader("x-nos-meta-" + key, userMap.get(key));
			}
		}
	}

	public static String getResultString(HttpResult result, String str) {
		String rs = "";
		if (result != null && result.getMsg() != null
				&& result.getMsg().has(str)) {
			try {
				rs = result.getMsg().getString(str);
			} catch (JSONException e) {
				LogUtil.e(LOGTAG, "get result string parse json failed", e);
			}
		}
		return rs;
	}

	public static void checkParameters(Context context, File file,
			Object fileParam, WanNOSObject obj, Callback callback)
			throws InvalidParameterException {
		String uploadToken = obj.getUploadToken();
		String nosBucketName = obj.getNosBucketName();
		String nosObjectName = obj.getNosObjectName();
		if (context == null || file == null || fileParam == null || obj == null
				|| callback == null || uploadToken == null
				|| nosBucketName == null || nosObjectName == null) {
			throw new InvalidParameterException("parameters could not be null");
		}
	}

	private static String transformString(JSONArray array) {
		if (array == null || array.length() == 0) {
			return null;
		}
		String str = "";
		try {
			for (int i = 0; i < array.length(); i++) {
				str += array.getString(i);
				if (i != array.length() - 1) {
					str += ";";
				}
			}
		} catch (JSONException e) {
			LogUtil.e(LOGTAG, "get json string exception", e);
		}
		return str;
	}

	private static String replaceWithHttps(String str) {
		return str.replaceAll("http://", "https://");
	}

	private static String encode(String str)
			throws UnsupportedEncodingException {
		return URLEncoder.encode(str, WanAccelerator.getConf().getCharset());
	}
}
