package com.netease.cloud.nos.android.utils;

import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.params.ConnPerRoute;
import org.apache.http.conn.params.ConnPerRouteBean;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import android.content.Context;

import com.netease.cloud.nos.android.core.WanAccelerator;
import com.netease.cloud.nos.android.ssl.SSLTrustAllSocketFactory;

public class Http {
	private static HttpClient httpClient;

	public static HttpClient getHttpClient(Context ctx) {
		if (httpClient == null) {
			httpClient = buildHttpClient(ctx);
		}
		return httpClient;
	}

	private static HttpClient buildHttpClient(Context context) {
		HttpParams httpParams = new BasicHttpParams();
		ConnManagerParams.setMaxTotalConnections(httpParams, 10);
		ConnPerRoute connPerRoute = new ConnPerRouteBean(3);
		ConnManagerParams.setMaxConnectionsPerRoute(httpParams, connPerRoute);
		HttpProtocolParams.setVersion(httpParams, HttpVersion.HTTP_1_1);

		SchemeRegistry registry = new SchemeRegistry();
		registry.register(new Scheme("http", PlainSocketFactory
				.getSocketFactory(), 80));

		// registry.register(new Scheme("https", SSLCustomSocketFactory
		// .getSocketFactory(context), 443));

		registry.register(new Scheme("https", SSLTrustAllSocketFactory
				.getSocketFactory(), 443));

		ClientConnectionManager cm = new ThreadSafeClientConnManager(
				httpParams, registry);

		HttpClient httpClient = new DefaultHttpClient(cm, httpParams);

		httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
				WanAccelerator.getConf().getSoTimeout());
		httpClient.getParams().setParameter(
				CoreConnectionPNames.CONNECTION_TIMEOUT,
				WanAccelerator.getConf().getConnectionTimeout());

		return httpClient;
	}

}
