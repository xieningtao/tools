package com.netease.cloud.nos.android.core;

import com.netease.cloud.nos.android.constants.Constants;
import com.netease.cloud.nos.android.exception.InvalidChunkSizeException;

import android.text.format.DateUtils;

public class AcceleratorConf {

	private String lbsHost = "http://wanproxy.127.net/lbs";
	private String lbsIP = "http://223.252.196.38/lbs";
	private String monitorHost = "http://wanproxy.127.net";
	private String charset = "utf-8";

	private int connectionTimeout = 30 * 1000;
	private int soTimeout = 30 * 1000;
	private int chunkSize = 1024 * 128;
	private int chunkRetryCount = 2;
	private int queryRetryCount = 2;
	private long refreshInterval = DateUtils.HOUR_IN_MILLIS * 2;
	private long monitorInterval = DateUtils.SECOND_IN_MILLIS * 120;

	public String getLbsHost() {
		return lbsHost;
	}

	public void setLbsHost(String lbsHost) {
		this.lbsHost = lbsHost;
	}

	public String getLbsIP() {
		return lbsIP;
	}

	public void setLbsIP(String lbsIP) {
		this.lbsIP = lbsIP;
	}
	
	public String getMonitorHost() {
		return monitorHost;
	}
	
	public void setMontiroHost(String monitorHost) {
		this.monitorHost = monitorHost;
	}
	
	public String getCharset() {
		return charset;
	}

	public int getConnectionTimeout() {
		return connectionTimeout;
	}

	public void setConnectionTimeout(int connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}

	public int getSoTimeout() {
		return soTimeout;
	}

	public void setSoTimeout(int soTimeout) {
		this.soTimeout = soTimeout;
	}

	public int getChunkSize() {
		return chunkSize;
	}

	public void setChunkSize(int chunkSize) throws InvalidChunkSizeException {
		if (chunkSize > Constants.MAX_CHUNK_SIZE
				|| chunkSize < Constants.MIN_CHUNK_SIZE) {
			throw new InvalidChunkSizeException();
		}
		this.chunkSize = chunkSize;
	}

	public int getChunkRetryCount() {
		return chunkRetryCount;
	}

	public void setChunkRetryCount(int chunkRetryCount) {
		this.chunkRetryCount = chunkRetryCount;
	}

	public int getQueryRetryCount() {
		return queryRetryCount;
	}

	public void setQueryRetryCount(int queryRetryCount) {
		this.queryRetryCount = queryRetryCount;
	}
	
	public long getRefreshInterval() {
		return refreshInterval;
	}

	public void setRefreshInterval(long refreshInterval) {
		this.refreshInterval = refreshInterval;
	}

	public long getMonitorInterval() {
		return monitorInterval;
	}

	public void setMonitorInterval(long monitorInterval) {
		this.monitorInterval = monitorInterval;
	}

}
