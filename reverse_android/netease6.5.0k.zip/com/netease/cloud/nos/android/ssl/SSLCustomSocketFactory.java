package com.netease.cloud.nos.android.ssl;

import java.io.InputStream;
import java.security.KeyStore;
import org.apache.http.conn.ssl.SSLSocketFactory;
import com.netease.cloud.nos.android.utils.LogUtil;
import android.content.Context;

public class SSLCustomSocketFactory extends SSLSocketFactory {

	private static final String LOGTAG = LogUtil
			.makeLogTag(SSLCustomSocketFactory.class);

	private static final String KEY_PASS = "";

	public SSLCustomSocketFactory(KeyStore trustStore) throws Throwable {
		super(trustStore);
	}

	public static SSLSocketFactory getSocketFactory(Context context) {
		try {
			InputStream ins = context.getResources().openRawResource(0); // get
																			// cert
																			// inputstream
			KeyStore trustStore = KeyStore.getInstance(KeyStore
					.getDefaultType());
			try {
				trustStore.load(ins, KEY_PASS.toCharArray());
			} finally {
				ins.close();
			}
			SSLSocketFactory factory = new SSLCustomSocketFactory(trustStore);
			return factory;
		} catch (Throwable e) {
			LogUtil.d(LOGTAG, "ssl socket factory exception", e);
		}
		return null;
	}
}