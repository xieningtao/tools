package com.netease.cloud.nos.android.constants;

public class Code {
	public final static int HTTP_SUCCESS = 200;
	public final static int LBS_ERROR = 400;
	public final static int INVALID_TOKEN = 403;
	public final static int CACHE_EXPIRED = 404;
	public final static int SERVER_ERROR = 500;
	public final static int CALLBACK_ERROR = 520;
	public final static int UPLOADING_CANCEL = 600;
	public final static int INVALID_OFFSET = 699;
	public final static int HTTP_EXCEPTION = 799;
	public final static int HTTP_NO_RESPONSE = 899;
	public final static int UNKNOWN_REASON = 999;

	public final static int MONITOR_SUCCESS = 0;
	public final static int MONITOR_FAIL = 1;
	public final static int MONITOR_CANCELED = 2;

	public static boolean isOK(int code) {
		if (code == HTTP_SUCCESS) {
			return true;
		} else {
			return false;
		}
	}

	public static String getDes(int code) {
		String str = "could not upload file with unknown reason, please contact with us";
		switch (code) {
		case HTTP_SUCCESS:
			str = "file upload success";
			break;
		case LBS_ERROR:
			str = "could not find uploader host to upload file, please wait for lbs recover";
			break;
		case INVALID_TOKEN:
			str = "could not upload file with invalid token, please change your token before uploading";
			break;
		case SERVER_ERROR:
			str = "could not upload file with server inner error, please contact with us";
			break;
		case HTTP_EXCEPTION:
			str = "could not upload file with http exception, please wait for network recover";
			break;
		case HTTP_NO_RESPONSE:
			str = "could not upload file with no http response, please contact with us";
			break;
		case UNKNOWN_REASON:
			str = "could not upload file with unknown reason, please contact with us";
			break;
		}
		return str;
	}
}
