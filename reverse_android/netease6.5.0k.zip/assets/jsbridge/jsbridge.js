(function() {
    if(window.jsonRPC) {
        return;
    }
    if(typeof YixinEvent === 'undefined') {

        YixinEvent = function(type, detail) {
            var ev = document.createEvent('Event');
            ev.initEvent(type, true, true, detail);
            ev.detail = detail;
            return ev;
        }
    }


    var jsonRPCData = 'rpcdata';
    var jsonRPCCall = 'rpccall';
    var CustomProtocolScheme = 'jsonrpc';
    var jsonRPCTag = 'jsonrpc';
    var jsonRPCResultTag = 'result';
    var jsonRPCErrorTag = 'error';
    var jsonRPCIdTag = 'id';
    var jsonRPCVer = '2.0';

    var _current_id = 0;

    var _callbacks = {};

    var jsonRPC = {};

    var nativeReady = false;
        var base64encodechars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 function base64encode(str) {
        if (str === undefined) {
            return str;
        }

        var out, i, len;
        var c1, c2, c3;
        len = str.length;
        i = 0;
        out = "";
        while (i < len) {
            c1 = str.charCodeAt(i++) & 0xff;
            if (i == len) {
                out += base64encodechars.charAt(c1 >> 2);
                out += base64encodechars.charAt((c1 & 0x3) << 4);
                out += "==";
                break;
            }
            c2 = str.charCodeAt(i++);
            if (i == len) {
                out += base64encodechars.charAt(c1 >> 2);
                out += base64encodechars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xf0) >> 4));
                out += base64encodechars.charAt((c2 & 0xf) << 2);
                out += "=";
                break;
            }
            c3 = str.charCodeAt(i++);
            out += base64encodechars.charAt(c1 >> 2);
            out += base64encodechars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xf0) >> 4));
            out += base64encodechars.charAt(((c2 & 0xf) << 2) | ((c3 & 0xc0) >> 6));
            out += base64encodechars.charAt(c3 & 0x3f);
        }
        return out;
    }
    var UTF8 = {
        encode: function(string) {
            string = string.replace(/\r\n/g, "\n");
            var utftext = "";

            for (var n = 0; n < string.length; n++) {

                var c = string.charCodeAt(n);

                if (c < 128) {
                    utftext += String.fromCharCode(c);
                } else if ((c > 127) && (c < 2048)) {
                    utftext += String.fromCharCode((c >> 6) | 192);
                    utftext += String.fromCharCode((c & 63) | 128);
                } else {
                    utftext += String.fromCharCode((c >> 12) | 224);
                    utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                    utftext += String.fromCharCode((c & 63) | 128);
                }

            }

            return utftext;
        },

        decode: function(utftext) {
            var string = "";
            var i = 0;
            var c = c1 = c2 = 0;

            while (i < utftext.length) {

                c = utftext.charCodeAt(i);

                if (c < 128) {
                    string += String.fromCharCode(c);
                    i++;
                } else if ((c > 191) && (c < 224)) {
                    c2 = utftext.charCodeAt(i + 1);
                    string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                    i += 2;
                } else {
                    c2 = utftext.charCodeAt(i + 1);
                    c3 = utftext.charCodeAt(i + 2);
                    string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                    i += 3;
                }

            }

            return string;
        }

    };
   function CommandQueue() {
        this.backQueue = [];
        this.queue = [];
    };

    CommandQueue.prototype.dequeue = function() {
        if(this.queue.length <=0 && this.backQueue.length > 0) {
            this.queue = this.backQueue.reverse();
            this.backQueue = [];
        }
        return   this.queue.pop();
    };

    CommandQueue.prototype.enqueue = function(item) {
        this.backQueue.push(item);
    };


        Object.defineProperty(CommandQueue.prototype, 'length',
        {get: function() {return this.queue.length + this.backQueue.length; }});


    var commandQueue = new CommandQueue();
    function filterObj(obj){
        for(var i in obj){
            if (obj.hasOwnProperty(i))
            {
                if(typeof obj[i] == 'string'){
                    obj[i] = obj[i].replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '');
                }
            }
        }
        return obj;
    }
    function _nativeExec(){
        var command = commandQueue.dequeue();
        if(command) {
            nativeReady = false;
            var jsoncommand = JSON.stringify(command);
            var _temp = prompt('huatianjsbridge://dispatch/' + base64encode(UTF8.encode(jsoncommand)),'');
            return true;
        } else {
            return false;
        }

    }


function doCall(request, success_cb, error_cb) {

        if (jsonRPCIdTag in request && typeof success_cb !== 'undefined') {
            _callbacks[request.id] = { success_cb: success_cb, error_cb: error_cb };
        }
        commandQueue.enqueue(request);
        if(nativeReady) {
            _nativeExec();
        }

    }

    function doClose() {
        delete window.jsbridge;
    }


    jsonRPC.call = function(method, params, success_cb, error_cb) {

        var request = {
            jsonrpc : jsonRPCVer,
            method  : method,
            params  : params,
            id      : _current_id++
        };
        doCall(request, success_cb, error_cb);
    };

    jsonRPC.notify = function(method, params) {
        var request = {
            jsonrpc : jsonRPCVer,
            method  : method,
            params  : params,
        };
        doCall(request, null, null);
    };

    jsonRPC.close = function() {
        doClose();
    };



    jsonRPC.onMessage = function(message) {
        var response = message;

        if(typeof response === 'object'
            && jsonRPCTag in response
            && response.jsonrpc === jsonRPCVer) {
            if(jsonRPCResultTag in response && _callbacks[response.id]) {
                var success_cb = _callbacks[response.id].success_cb;
                delete _callbacks[response.id];
                success_cb(response.result);
                return;
            } else if(jsonRPCErrorTag in response && _callbacks[response.id]) {

                var error_cb = _callbacks[response.id].error_cb;
                delete _callbacks[response.id];
                error_cb(response.error);
                return;
            }
        }
    };

    jsonRPC.ready = function() {

        jsonRPC.nativeEvent.on('NativeReady', function(e) {
            nativeReady = false;
            if(!_nativeExec()) {
                nativeReady = true;
            }
        });
        jsonRPC.nativeEvent.Trigger('NativeReady');
        jsonRPC.nativeEvent.Trigger('JSBridgeReady');
    };


    jsonRPC.invokeFinish = function() {
        nativeReady = true;
        _nativeExec();
    };

    jsonRPC.echo = function(message) {
        alert(message);
    };


        jsonRPC.nativeEvent = {};

    jsonRPC.nativeEvent.Trigger = function(type, detail) {
        var ev = YixinEvent(type,detail);
        document.dispatchEvent(ev);
    };
    
    jsonRPC.nativeEvent.Trigger2 = function(type, detail) {
        var has = jsonRPC.nativeEvent.has(type);
    
        var ev =  YixinEvent(type,detail);
        document.dispatchEvent(ev);
        
        if (!has) {
            var param = {
                type : type,
                detail : detail
            };
        
            jsonRPC.notify("trigger", JSON.stringify(param));
        }
    };

    var nativeEvent = {};

    jsonRPC.nativeEvent.on = function(type, cb) {
        document.addEventListener(type, cb, false);
        if(!nativeEvent[type]) {
            nativeEvent[type] = 1;
        }
    };

    jsonRPC.nativeEvent.once = function(type, cb) {
        document.addEventListener(type, function(e) {
            cb(e);
            document.removeEventListener(type);
        }, false);
    };

    jsonRPC.nativeEvent.off = function(type) {
        document.removeEventListener(type);
        delete nativeEvent[type];
    };

    jsonRPC.nativeEvent.off = function() {
        for(var key in nativeEvent) {
            jsonRPC.nativeEvent.off(key);
        }
        nativeEvent = {};
    };
    
    jsonRPC.nativeEvent.has = function(type) {
        return nativeEvent[type] === 1;
    };


    
    var doc = document;
    
    window.jsbridge = {};
    window.jsbridge = jsonRPC;
    window.jsonRPC = jsonRPC;
    window.jsbridge.invoke = jsonRPC.call;
    window.jsbridge.call = jsonRPC.notify;
    window.jsbridge.on = jsonRPC.nativeEvent.on;
    window.jsbridge.off = jsonRPC.nativeEvent.off;
    window.jsbridge.emit = jsonRPC.nativeEvent.trigger;

})();

