# 说明

---

## 查看字节码工具

* jclasslib bytecode viewer（工具在tools目录下）

## 修改字节码工具

* javassit [官方文档](http://www.javassist.org/)
* asm pdf文档在doc里面 [官方文档](https://asm.ow2.io/)

### javassit

* 有两个级别的api可以对class文件进行修复
* 一个是通过源码级别进行修复（推荐，方法前，方法后其实就是return之前，某一个指令处）
* 一个是通过字节码的形式修复

### asm

* 相比javassit，它并没有源码级别的api
* 有两种方式遍历字节码，类似于xml的dom和sax方式
* 一般是通过sax这种模式来进行bytecode的遍历
* 几种工具：ASMifier--把class文件转化为asm代码，用ASMifier.class里面的main方法
TraceClassVisitor和TraceMethodVisitor可以把class文件转化为可读的文件，
一般用来打印修改字节码以后的class文件，当然也可以用jclasslib bytecode viewer来进行查看
* 注意：bytecode方法里面的指令遍历的时候，不同种类的指令会回调不同的方法，在Opcodes的注释里面有说明

### 遇到的问题
* 问题: ![引入类错误](./img/IMG20180930_171422.png)
出现此类问题有两个原因：1）可能是路径不对，最好保证按照包名的路径来放置依赖的类，那些类都是内部类，
java编译的机制是：一个class文件里面只能有一个类，匿名内部类就被打出去了
2）应用类的字节码对不上，这个可以通过jclasslib bytecode viewer工具进行查看，比如说$1这个匿名内部类
在PushClient.class里面的具体是引用什么类，就去找相应的文件，看是否能够对得上。我在这里摔了一个大坑
* 代码最终经过测试的时候，如果报出堆栈信息来，就用工具去查看进行验证就行了。

### 关于
* 本demo里面是通过修改PushClient.clas里面的getTokenAsyn方法，给他添加空指针保护