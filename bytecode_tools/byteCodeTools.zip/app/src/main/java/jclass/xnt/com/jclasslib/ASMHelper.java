package jclass.xnt.com.jclasslib;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ASMHelper {

    public static void modifyMethodByASM() throws IOException {
        FileInputStream is = new FileInputStream("C:\\Users\\g8876\\Desktop\\jclassLib\\app\\testcase\\com\\netease\\inner\\pushclient\\huawei\\PushClient.class");
        ClassReader cr = new ClassReader(is);
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        ClassAdapter classAdapter = new ClassAdapter(cw);

        cr.accept(classAdapter, 0);

        FileOutputStream fos = new FileOutputStream("C:\\Users\\g8876\\Desktop\\jclassLib\\app\\asmtarget\\PushClient.class");
        fos.write(cw.toByteArray());
        fos.close();
    }

    static class ClassAdapter extends ClassVisitor implements Opcodes {

        public ClassAdapter() {
            super(ASM6);
        }

        public ClassAdapter(ClassVisitor classVisitor) {
            super(ASM6, classVisitor);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {

            MethodVisitor methodVisitor = super.visitMethod(access, name, descriptor, signature, exceptions);
            System.out.println("classVisitor visitMethod name: " + name + " descriptor: " + descriptor);
            if (name.equals("getTokenAsyn")) {
                return new MethodAdapter(methodVisitor);
            }
            return methodVisitor;
        }

        @Override
        public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
            System.out.println("ClassVisitor visitField name: " + name + " descriptor: " + descriptor);
            return super.visitField(access, name, descriptor, signature, value);
        }
    }

    static class MethodAdapter extends MethodVisitor implements Opcodes {
        //        private Label label;
        private boolean insertInstruction = false;

        public MethodAdapter() {
            super(ASM6);
        }

        public MethodAdapter(MethodVisitor methodVisitor) {
            super(ASM6, methodVisitor);
        }

        @Override
        public void visitCode() {
            System.out.println("visitCode");
            insertInstruction = true;
            super.visitCode();
        }


        @Override
        public void visitInsn(int opcode) {
            super.visitInsn(opcode);
            System.out.println("methodVisitor visitInsn opcode: " + opcode);
        }

        @Override
        public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
            super.visitFieldInsn(opcode, owner, name, descriptor);
            System.out.println("methodVisitor visitFieldInsn opcode: " + opcode + " owner: " + owner + " name: " + name + " descriptor: " + descriptor);
        }

        @Override
        public void visitJumpInsn(int opcode, Label label) {
            super.visitJumpInsn(opcode, label);
            System.out.println("methodVisitor opcode: " + opcode + " label: " + label);
        }

        @Override
        public void visitLabel(Label label) {
            if (insertInstruction) {
                mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
                mv.visitLdcInsn("this is modify by asm");
                mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);

                mv.visitFieldInsn(GETSTATIC, "com/netease/inner/pushclient/huawei/PushClient", "client", "Lcom/huawei/hms/api/HuaweiApiClient;");
//            label = new Label();
                mv.visitJumpInsn(IFNONNULL, label);
                mv.visitInsn(RETURN);
                mv.visitLabel(label);

                insertInstruction = false;
            }
            System.out.println("methodVisitor visitLabel label: " + label.toString());
            super.visitLabel(label);

        }

        @Override
        public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
            System.out.println("methodVisitor visitMethodInsn name: " + name + " opcode: " + opcode + " descriptor: " + descriptor);
            super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);

        }


        @Override
        public void visitEnd() {
            super.visitEnd();
            System.out.println("visitEnd()");
        }

        @Override
        public void visitMaxs(int maxStack, int maxLocals) {
            System.out.println("visitMax maxstack: " + maxStack + " maxLocals: " + maxLocals);
            super.visitMaxs(maxStack, maxLocals);
        }

        @Override
        public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack) {
            super.visitFrame(type, nLocal, local, nStack, stack);
        }
    }
}
