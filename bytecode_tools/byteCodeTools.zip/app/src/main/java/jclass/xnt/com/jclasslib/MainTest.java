package jclass.xnt.com.jclasslib;

import java.io.IOException;

public class MainTest {

    public static void main(String[] args){
        System.out.print("hello");
        JavassistHelper.modifyClassByJavassist();
        try {
            ASMHelper.modifyMethodByASM();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
