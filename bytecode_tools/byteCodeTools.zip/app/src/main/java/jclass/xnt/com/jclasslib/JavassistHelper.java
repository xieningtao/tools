package jclass.xnt.com.jclasslib;

import java.io.IOException;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.NotFoundException;

public class JavassistHelper {


    public static void  modifyClassByJavassist(){
        ClassPool pool = ClassPool.getDefault();
        try {
            CtClass cc = pool.get("com.netease.inner.pushclient.huawei.PushClient");
//            CtMethod[] ctMethod = cc.getMethods();
            CtMethod tokenAsynMethod = cc.getDeclaredMethod("getTokenAsyn");
//            tokenAsynMethod.setName("getTokenAsynModify");
            tokenAsynMethod.insertBefore("System.out.println(\"this is modify by javassist\");if(client == null){return;}");

//            CtMethod newTokenMethod = CtMethod.make("private static void getTokenAsyn(){System.out.println(\"hello\");}",cc);
//            newTokenMethod.
//            cc.addMethod(newTokenMethod);
            cc.writeFile("C:\\Users\\g8876\\Desktop\\jclassLib\\app\\javassisttarget");
        } catch (NotFoundException e) {
            e.printStackTrace();
        } catch (CannotCompileException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
