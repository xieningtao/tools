package jclass.xnt.com.jclasslib;

public class Test {

    public void sayHello(){
        System.out.println("hello");
    }
}
